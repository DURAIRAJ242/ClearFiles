# Clear Files

Ad-free, offline File Manager for Android (Kotlin + Jetpack Compose).
No internet permission, no ads, no trackers.

## Features
- Home: storage usage, categories (Images, Videos, Audio, Documents, Archives, APKs, Downloads), recent files
- Browse every folder on internal storage and SD card, with a tappable path bar
- Search: all files on the phone from Home, or inside the current folder
- Favourites: tap the heart on any file or folder
- Edit: rename, copy, move, delete, new folder, new text file, compress to ZIP, extract ZIP, built-in text editor, share, details
- Sort: name, date, size, type (both directions, folders first)
- Filter: folders, images, videos, audio, documents, archives, APKs, other; show/hide hidden files
- Light and dark themes

## Build the APK on your phone with GitHub (free)
1. Create a NEW GitHub repository (for example `Clear-Files-App`).
2. Upload `ClearFiles.zip` (do not unzip it).
3. Add file > Create new file, name it `.github/workflows/build.yml` and paste the workflow text.
4. Open the Actions tab, wait for the green tick, download `ClearFiles-apk`, unzip it, tap the `.apk`.

## First run
Android will ask you to turn on "Allow access to manage all files" for the app. This is needed to show every file.


## v2 additions
- Samsung-style Home: Recent files, categories, separate Internal / SD card / Other storage cards, analyze tools
- Storage detail page per volume (usage bar by file type)
- Recent tab, Select-multiple button, Show/Hide hidden files eye button
- Duplicate file analyzer (size, then MD5), keeps one copy per group
- Recycle bin (30 days, restore / delete forever / empty)
- Secure folder: PIN + optional fingerprint/phone lock, app-private storage. Uninstalling or clearing data deletes its files.
