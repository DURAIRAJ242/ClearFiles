package com.clearfiles.app.util

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.clearfiles.app.data.FileItem
import com.clearfiles.app.data.StorageInfo
import com.clearfiles.app.data.StorageKind
import com.clearfiles.app.data.StorageRoot
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val shortFmt = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault())
private val fullFmt = DateTimeFormatter.ofPattern("EEE, d MMM yyyy · h:mm a", Locale.getDefault())

fun shortDate(millis: Long): String =
    Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).format(shortFmt)

fun fullDate(millis: Long): String =
    Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).format(fullFmt)

fun formatSize(bytes: Long): String {
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1 -> String.format(Locale.getDefault(), "%.2f GB", gb)
        mb >= 1 -> String.format(Locale.getDefault(), "%.1f MB", mb)
        kb >= 1 -> String.format(Locale.getDefault(), "%.0f KB", kb)
        else -> "$bytes B"
    }
}

fun mimeFor(ext: String): String =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"

/** Internal storage first, then any mounted SD card / USB drive. */
fun findRoots(context: Context): List<StorageRoot> {
    val fallback = StorageRoot(
        "Internal storage",
        Environment.getExternalStorageDirectory().path,
        true,
    )
    return try {
        val sm = context.getSystemService(Context.STORAGE_SERVICE) as StorageManager
        var sdTaken = false
        val list = sm.storageVolumes.mapNotNull { v ->
            val dir = v.directory ?: return@mapNotNull null
            if (v.state != Environment.MEDIA_MOUNTED) return@mapNotNull null
            if (v.isPrimary) {
                StorageRoot("Internal storage", dir.path, true, StorageKind.Internal)
            } else {
                val description = v.getDescription(context) ?: "SD card"
                val isUsb = description.contains("usb", ignoreCase = true) ||
                    description.contains("otg", ignoreCase = true)
                if (isUsb || sdTaken) {
                    StorageRoot(description, dir.path, false, StorageKind.Other)
                } else {
                    sdTaken = true
                    StorageRoot(description, dir.path, false, StorageKind.SdCard)
                }
            }
        }
        if (list.isEmpty()) listOf(fallback) else list.sortedByDescending { it.primary }
    } catch (e: Exception) {
        listOf(fallback)
    }
}

tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Asks for fingerprint / face, or the phone's screen lock as a fallback. */
fun authenticateDevice(
    context: Context,
    title: String,
    onSuccess: () -> Unit,
    onFail: (String) -> Unit,
) {
    try {
        val prompt = BiometricPrompt.Builder(context)
            .setTitle(title)
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL,
            )
            .build()
        prompt.authenticate(
            CancellationSignal(),
            ContextCompat.getMainExecutor(context),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    onFail(errString?.toString() ?: "Couldn't verify it's you")
                }
            },
        )
    } catch (e: Exception) {
        onFail("Not available on this phone. Use your PIN.")
    }
}

fun readStorageInfo(path: String): StorageInfo? = try {
    val s = StatFs(path)
    StorageInfo(total = s.totalBytes, free = s.availableBytes)
} catch (e: Exception) {
    null
}

fun downloadsPath(): String =
    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).path

private fun uriFor(context: Context, path: String) =
    FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(path))

fun openFile(context: Context, item: FileItem) {
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uriFor(context, item.path), mimeFor(item.ext))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "No app found to open this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Couldn't open this file", Toast.LENGTH_SHORT).show()
    }
}

fun shareFiles(context: Context, items: List<FileItem>) {
    val files = items.filter { !it.isDir }
    if (files.isEmpty()) return
    try {
        val intent = if (files.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = mimeFor(files[0].ext)
                putExtra(Intent.EXTRA_STREAM, uriFor(context, files[0].path))
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                val mimes = files.map { mimeFor(it.ext) }.toSet()
                type = if (mimes.size == 1) mimes.first() else "*/*"
                putParcelableArrayListExtra(
                    Intent.EXTRA_STREAM,
                    ArrayList(files.map { uriFor(context, it.path) }),
                )
            }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Share"))
    } catch (e: Exception) {
        Toast.makeText(context, "Couldn't share these files", Toast.LENGTH_SHORT).show()
    }
}
