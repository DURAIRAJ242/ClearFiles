@file:OptIn(ExperimentalMaterial3Api::class)

package com.clearfiles.app.ui

import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clearfiles.app.FilesViewModel
import com.clearfiles.app.data.VaultEntry
import com.clearfiles.app.data.asFileItem
import com.clearfiles.app.util.authenticateDevice
import com.clearfiles.app.util.findActivity
import com.clearfiles.app.util.formatSize
import com.clearfiles.app.util.openFile
import com.clearfiles.app.util.shortDate

@Composable
fun SecureScreen(vm: FilesViewModel, snackbar: SnackbarHostState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val hasPin by vm.hasPin.collectAsStateWithLifecycle()
    val unlocked by vm.secureUnlocked.collectAsStateWithLifecycle()

    // Hide this page from screenshots and the recent-apps preview.
    DisposableEffect(Unit) {
        val window = ctx.findActivity()?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    BackHandler(onBack = onClose)

    when {
        !hasPin -> PinSetup(snackbar, onClose, onCreate = vm::setPin)
        !unlocked -> PinUnlock(snackbar, onClose, onPin = vm::unlockWithPin, onDevice = vm::unlockWithDevice)
        else -> SecureContent(vm, snackbar, onClose)
    }
}

@Composable
private fun PinField(label: String, value: String, onChange: (String) -> Unit, onDone: (() -> Unit)? = null) {
    OutlinedTextField(
        value = value,
        onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) onChange(it) },
        label = { Text(label) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(
            keyboardType = KeyboardType.NumberPassword,
            imeAction = if (onDone != null) ImeAction.Done else ImeAction.Next,
        ),
        keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun PinSetup(snackbar: SnackbarHostState, onClose: () -> Unit, onCreate: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var problem by remember { mutableStateOf<String?>(null) }

    OverlayScaffold("Secure folder", onClose, snackbar) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            LockBadge()
            Text("Create a PIN", style = MaterialTheme.typography.headlineSmall)
            Text(
                "Files you move here are kept privately inside this app, hidden from the gallery and other apps. Choose a 4–6 digit PIN.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
            )
            NoteCard(
                "If you uninstall the app or clear its data, files in the Secure folder are deleted. Move them out first. A forgotten PIN can't be recovered.",
                warning = true,
            )
            PinField("PIN", pin, { pin = it })
            PinField("Confirm PIN", confirm, { confirm = it })
            problem?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = {
                    when {
                        pin.length < 4 -> problem = "PIN must be 4 to 6 digits"
                        pin != confirm -> problem = "The two PINs don't match"
                        else -> onCreate(pin)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Create PIN") }
        }
    }
}

@Composable
private fun PinUnlock(
    snackbar: SnackbarHostState,
    onClose: () -> Unit,
    onPin: (String) -> String?,
    onDevice: () -> Unit,
) {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var problem by remember { mutableStateOf<String?>(null) }

    fun submit() {
        problem = onPin(pin)
        if (problem != null) pin = ""
    }

    OverlayScaffold("Secure folder", onClose, snackbar) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            LockBadge()
            Text("Enter your PIN", style = MaterialTheme.typography.headlineSmall)
            PinField("PIN", pin, { pin = it }, onDone = { submit() })
            problem?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = { submit() },
                enabled = pin.length >= 4,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Unlock") }
            OutlinedButton(
                onClick = {
                    authenticateDevice(
                        ctx,
                        "Unlock Secure folder",
                        onSuccess = onDevice,
                        onFail = { problem = it },
                    )
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Use fingerprint or phone lock") }
        }
    }
}

@Composable
private fun SecureContent(vm: FilesViewModel, snackbar: SnackbarHostState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val entries by vm.secureEntries.collectAsStateWithLifecycle()
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var confirmDelete by remember { mutableStateOf(false) }
    val chosen = entries.filter { it.id in selectedIds }

    OverlayScaffold(
        title = "Secure folder",
        onClose = onClose,
        snackbar = snackbar,
        actions = {
            IconButton(onClick = { vm.lockSecure() }) { Icon(Icons.Rounded.Lock, "Lock now") }
        },
        bottomBar = {
            if (chosen.isNotEmpty()) {
                BottomActionBar {
                    Button(
                        onClick = {
                            vm.moveOutOfSecure(chosen)
                            selectedIds = emptySet()
                        },
                        modifier = Modifier.weight(1f),
                    ) { Text("Move out") }
                    OutlinedButton(
                        onClick = { confirmDelete = true },
                        modifier = Modifier.weight(1f),
                    ) { Text("Delete") }
                }
            }
        },
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState(
                Icons.Rounded.Lock,
                "Nothing here yet",
                "In Browse, select files, tap More, then “Move to Secure folder”.",
                Modifier.padding(padding),
            )
        } else {
            LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(bottom = 24.dp)) {
                item {
                    NoteCard(
                        "Files here are stored privately inside this app. Uninstalling it or clearing its data deletes them.",
                        Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        warning = true,
                    )
                }
                items(entries, key = { it.id }) { e ->
                    SecureRow(
                        entry = e,
                        checked = e.id in selectedIds,
                        onToggle = {
                            selectedIds = if (e.id in selectedIds) selectedIds - e.id else selectedIds + e.id
                        },
                        onOpen = { if (!e.isDir) openFile(ctx, e.asFileItem()) },
                    )
                }
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = "Delete forever?",
            message = "${chosen.size} item${if (chosen.size == 1) "" else "s"} will be permanently deleted. This can't be undone.",
            confirmText = "Delete",
            onConfirm = {
                confirmDelete = false
                vm.deleteFromSecure(chosen)
                selectedIds = emptySet()
            },
            onDismiss = { confirmDelete = false },
        )
    }
}

@Composable
private fun SecureRow(entry: VaultEntry, checked: Boolean, onToggle: () -> Unit, onOpen: () -> Unit) {
    val item = entry.asFileItem()
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = { onToggle() }, modifier = Modifier.padding(4.dp))
        FileThumb(item.path, item.type, 46.dp)
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(entry.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${formatSize(entry.size)} · Added ${shortDate(entry.deletedAt)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
