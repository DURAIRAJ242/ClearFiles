package com.clearfiles.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.clearfiles.app.data.Clip
import com.clearfiles.app.data.DuplicateGroup
import com.clearfiles.app.data.EditorState
import com.clearfiles.app.data.FavoritesStore
import com.clearfiles.app.data.FileItem
import com.clearfiles.app.data.FileOps
import com.clearfiles.app.data.FileType
import com.clearfiles.app.data.NavTab
import com.clearfiles.app.data.Screen
import com.clearfiles.app.data.SortField
import com.clearfiles.app.data.StorageBreakdown
import com.clearfiles.app.data.StorageRoot
import com.clearfiles.app.data.UiState
import com.clearfiles.app.data.Vault
import com.clearfiles.app.data.VaultEntry
import com.clearfiles.app.data.hashPin
import com.clearfiles.app.data.sortItems
import com.clearfiles.app.data.toFileItem
import com.clearfiles.app.util.downloadsPath
import com.clearfiles.app.util.findRoots
import com.clearfiles.app.util.readStorageInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.util.UUID

class FilesViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val securePrefs = app.getSharedPreferences("secure", Context.MODE_PRIVATE)
    private val favStore = FavoritesStore(app)
    private val secureVault = Vault(File(app.filesDir, "secure"))

    val roots: List<StorageRoot> = findRoots(app)
    val favourites: StateFlow<Set<String>> = favStore.paths

    private val _ui = MutableStateFlow(
        UiState(
            dir = roots.first().path,
            sortField = runCatching { SortField.valueOf(prefs.getString("sortField", "") ?: "") }
                .getOrDefault(SortField.Name),
            ascending = prefs.getBoolean("ascending", true),
            showHidden = prefs.getBoolean("showHidden", false),
        ),
    )
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private val _dirItems = MutableStateFlow<List<FileItem>>(emptyList())
    private val _all = MutableStateFlow<List<FileItem>>(emptyList())
    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()

    val selected = MutableStateFlow<Set<String>>(emptySet())
    /** True while the "select multiple" mode is on (even with nothing ticked yet). */
    val selectMode = MutableStateFlow(false)
    val clipboard = MutableStateFlow<Clip?>(null)
    val busy = MutableStateFlow<String?>(null)
    val editor = MutableStateFlow<EditorState?>(null)
    val breakdowns = MutableStateFlow<List<StorageBreakdown>>(emptyList())

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    /** What the list on screen should show right now. */
    val visible: StateFlow<List<FileItem>> =
        combine(_ui, _dirItems, _all, favStore.paths) { s, dir, all, favs ->
            computeVisible(s, dir, all, favs)
        }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val counts: StateFlow<Map<FileType, Int>> = _all
        .map { list -> list.filter { !it.isDir }.groupingBy { it.type }.eachCount() }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val recents: StateFlow<List<FileItem>> = _all
        .map { list -> list.filter { !it.isDir }.sortedByDescending { it.modified }.take(12) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- loading -------------------------------------------------------------------------

    private var started = false
    private var lastScan = 0L
    private var dirJob: Job? = null
    private var scanJob: Job? = null

    /** Call once the "all files" permission has been granted. */
    fun start() {
        if (started) return
        started = true
        loadDir()
        rescan()
        updateStorage()
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val cutoff = System.currentTimeMillis() - TRASH_DAYS * 24L * 60 * 60 * 1000
                roots.forEach { runCatching { trashVault(it).purgeOlderThan(cutoff) } }
            }
            refreshTrash()
        }
        refreshSecure()
    }

    fun onResume() {
        if (!started) return
        loadDir()
        updateStorage()
        if (System.currentTimeMillis() - lastScan > 120_000L) rescan()
    }

    fun loadDir() {
        dirJob?.cancel()
        val s = _ui.value
        dirJob = viewModelScope.launch {
            val items = withContext(Dispatchers.IO) { FileOps.listDir(File(s.dir), s.showHidden) }
            _dirItems.value = items
        }
    }

    fun rescan() {
        scanJob?.cancel()
        scanJob = viewModelScope.launch {
            _scanning.value = true
            val list = withContext(Dispatchers.IO) {
                FileOps.scanAll(roots.map { File(it.path) }) { isActive }
            }
            _all.value = list
            breakdowns.value = withContext(Dispatchers.Default) { computeBreakdowns(list) }
            lastScan = System.currentTimeMillis()
            _scanning.value = false
        }
    }

    private fun updateStorage() {
        breakdowns.value = computeBreakdowns(_all.value)
    }

    private fun computeBreakdowns(list: List<FileItem>): List<StorageBreakdown> =
        roots.map { r ->
            val prefix = r.path + "/"
            val byType = HashMap<FileType, Long>()
            for (f in list) {
                if (!f.isDir && f.path.startsWith(prefix)) {
                    byType[f.type] = (byType[f.type] ?: 0L) + f.size
                }
            }
            val info = readStorageInfo(r.path)
            StorageBreakdown(r, info?.total ?: 0L, info?.free ?: 0L, byType)
        }

    // ---- navigation ----------------------------------------------------------------------

    fun rootFor(dir: String): StorageRoot =
        roots.firstOrNull { dir == it.path || dir.startsWith(it.path + "/") } ?: roots.first()

    fun setTab(tab: NavTab) {
        clearSelection()
        _ui.update {
            it.copy(tab = tab, category = null, largeFiles = false, searching = false, query = "", filter = null)
        }
        if (tab == NavTab.Browse) loadDir()
    }

    fun openCategory(type: FileType) {
        clearSelection()
        _ui.update {
            it.copy(tab = NavTab.Home, category = type, largeFiles = false, searching = false, query = "", filter = null)
        }
    }

    fun openLargeFiles() {
        clearSelection()
        _ui.update {
            it.copy(tab = NavTab.Home, category = null, largeFiles = true, searching = false, query = "", filter = null)
        }
    }

    fun openFolder(path: String) {
        if (!File(path).isDirectory) return
        clearSelection()
        _ui.update {
            it.copy(
                tab = NavTab.Browse, dir = path, category = null, largeFiles = false,
                searching = false, query = "", filter = null,
            )
        }
        loadDir()
    }

    fun back() {
        val s = _ui.value
        when {
            s.tab == NavTab.Home && (s.category != null || s.largeFiles) ->
                _ui.update { it.copy(category = null, largeFiles = false, query = "", filter = null) }

            s.tab == NavTab.Browse -> {
                val root = rootFor(s.dir)
                if (s.dir != root.path) {
                    openFolder(File(s.dir).parent ?: root.path)
                } else {
                    setTab(NavTab.Home)
                }
            }

            s.tab == NavTab.Favourites || s.tab == NavTab.Recent -> setTab(NavTab.Home)
        }
    }

    // ---- full-screen tools ---------------------------------------------------------------

    val screen = MutableStateFlow<Screen?>(null)
    val detailRoot = MutableStateFlow<StorageRoot?>(null)

    fun openScreen(s: Screen) {
        screen.value = s
        when (s) {
            Screen.RecycleBin -> refreshTrash()
            Screen.Secure -> refreshSecure()
            Screen.Duplicates -> if (_dupGroups.value == null) analyzeDuplicates()
            Screen.StorageDetail -> {}
        }
    }

    fun openStorageDetail(root: StorageRoot) {
        detailRoot.value = root
        screen.value = Screen.StorageDetail
    }

    fun closeScreen() {
        if (screen.value == Screen.Secure) lockSecure()
        screen.value = null
    }

    // ---- sort / filter / search ----------------------------------------------------------

    fun setSort(field: SortField, ascending: Boolean) {
        _ui.update { it.copy(sortField = field, ascending = ascending) }
        prefs.edit().putString("sortField", field.name).putBoolean("ascending", ascending).apply()
    }

    fun setFilter(type: FileType?) = _ui.update { it.copy(filter = type) }

    fun setShowHidden(show: Boolean) {
        _ui.update { it.copy(showHidden = show) }
        prefs.edit().putBoolean("showHidden", show).apply()
        loadDir()
    }

    fun openSearch() = _ui.update { it.copy(searching = true, query = "") }
    fun closeSearch() = _ui.update { it.copy(searching = false, query = "") }
    fun setQuery(query: String) = _ui.update { it.copy(query = query) }

    // ---- selection / favourites ----------------------------------------------------------

    fun startSelect() { selectMode.value = true }

    fun toggleSelect(path: String) {
        selectMode.value = true
        selected.update { if (path in it) it - path else it + path }
    }

    fun clearSelection() {
        selected.value = emptySet()
        selectMode.value = false
    }

    fun toggleSelectAll() {
        val all = visible.value.map { it.path }.toSet()
        selectMode.value = true
        selected.value = if (all.isNotEmpty() && selected.value.containsAll(all)) emptySet() else all
    }

    fun toggleFavourite(path: String) = favStore.toggle(path)
    fun setFavourites(items: List<FileItem>, favorite: Boolean) =
        favStore.setAll(items.map { it.path }, favorite)

    // ---- clipboard (copy / move) ---------------------------------------------------------

    fun copyToClipboard(items: List<FileItem>, cut: Boolean) {
        if (items.isEmpty()) return
        clipboard.value = Clip(items.map { it.path }, cut)
        clearSelection()
        _ui.update {
            it.copy(tab = NavTab.Browse, category = null, largeFiles = false, searching = false, query = "", filter = null)
        }
        loadDir()
        _messages.tryEmit("Open the destination folder, then tap Paste")
    }

    fun clearClipboard() { clipboard.value = null }

    fun paste() {
        val clip = clipboard.value ?: return
        val dest = File(_ui.value.dir)
        clipboard.value = null
        runOp(if (clip.cut) "Moving…" else "Copying…", if (clip.cut) "Moved" else "Copied") {
            for (p in clip.paths) {
                val src = File(p)
                if (!src.exists()) continue
                if (src.isDirectory && (dest.path == src.path || dest.path.startsWith(src.path + "/"))) {
                    throw IOException("Can't put a folder inside itself")
                }
                if (clip.cut && src.parentFile?.path == dest.path) continue
                val target = FileOps.uniqueFile(dest, src.name)
                if (clip.cut) {
                    FileOps.move(src, target)
                    favStore.replace(src.path, target.path)
                } else {
                    FileOps.copy(src, target)
                }
            }
        }
    }

    // ---- edit operations -----------------------------------------------------------------

    /** Delete = move to the Recycle bin (restorable for 30 days). */
    fun delete(items: List<FileItem>) {
        val n = items.size
        runOp("Moving to Recycle bin…", "Moved $n item${if (n == 1) "" else "s"} to Recycle bin") {
            for (item in items) trash(File(item.path))
        }
    }

    fun rename(item: FileItem, newName: String) {
        val name = newName.trim()
        val src = File(item.path)
        val target = File(src.parentFile, name)
        runOp("Renaming…", "Renamed") {
            if (target.path == src.path) return@runOp
            if (target.exists()) throw IOException("“$name” already exists")
            if (!src.renameTo(target)) throw IOException("Couldn't rename")
            favStore.replace(src.path, target.path)
        }
    }

    fun createFolder(name: String) {
        val target = File(File(_ui.value.dir), name.trim())
        runOp("Creating folder…", "Folder created") {
            if (target.exists()) throw IOException("“${target.name}” already exists")
            if (!target.mkdirs()) throw IOException("Couldn't create the folder")
        }
    }

    fun createTextFile(name: String) {
        val clean = name.trim().let { if (it.contains('.')) it else "$it.txt" }
        val target = File(File(_ui.value.dir), clean)
        runOp("Creating file…", "File created") {
            if (target.exists()) throw IOException("“${target.name}” already exists")
            if (!target.createNewFile()) throw IOException("Couldn't create the file")
        }
    }

    fun compress(items: List<FileItem>) {
        if (items.isEmpty()) return
        val dir = File(items.first().path).parentFile ?: return
        val base = if (items.size == 1) items[0].name.substringBeforeLast('.', items[0].name) else "Archive"
        val target = FileOps.uniqueFile(dir, "$base.zip")
        runOp("Compressing…", "Created ${target.name}") {
            FileOps.zip(items.map { File(it.path) }, target)
        }
    }

    fun extract(item: FileItem) {
        val zip = File(item.path)
        val dir = zip.parentFile ?: return
        val dest = FileOps.uniqueFile(dir, zip.nameWithoutExtension)
        runOp("Extracting…", "Extracted to ${dest.name}") {
            try {
                FileOps.unzip(zip, dest)
            } catch (e: Exception) {
                dest.deleteRecursively()
                throw IOException(e.message ?: "Couldn't extract this file")
            }
        }
    }

    // ---- recycle bin ---------------------------------------------------------------------

    val trashEntries = MutableStateFlow<List<VaultEntry>>(emptyList())

    private fun trashVault(root: StorageRoot) = Vault(File(root.path, FileOps.TRASH_DIR))

    private fun trash(file: File) {
        Vault(File(rootFor(file.path).path, FileOps.TRASH_DIR)).add(file)
        favStore.remove(file.path)
    }

    fun refreshTrash() {
        viewModelScope.launch {
            trashEntries.value = withContext(Dispatchers.IO) {
                roots.flatMap { runCatching { trashVault(it).list() }.getOrDefault(emptyList()) }
                    .sortedByDescending { it.deletedAt }
            }
        }
    }

    fun restoreFromTrash(entries: List<VaultEntry>) {
        runOp("Restoring…", "Restored ${entries.size} item${if (entries.size == 1) "" else "s"}") {
            for (e in entries) Vault(File(e.vaultDir)).restore(e, File(downloadsPath()))
        }
    }

    fun deleteFromTrashForever(entries: List<VaultEntry>) {
        runOp("Deleting…", "Deleted forever") {
            for (e in entries) Vault(File(e.vaultDir)).deleteForever(e)
        }
    }

    fun emptyTrash() = deleteFromTrashForever(trashEntries.value)

    // ---- duplicate files -----------------------------------------------------------------

    private val _dupGroups = MutableStateFlow<List<DuplicateGroup>?>(null)
    val dupGroups: StateFlow<List<DuplicateGroup>?> = _dupGroups.asStateFlow()
    val dupBusy = MutableStateFlow(false)
    val dupSelected = MutableStateFlow<Set<String>>(emptySet())
    private var dupJob: Job? = null

    fun analyzeDuplicates() {
        dupJob?.cancel()
        dupJob = viewModelScope.launch {
            dupBusy.value = true
            dupSelected.value = emptySet()
            scanJob?.join() // wait for the file list to be complete
            val files = _all.value
            val groups = withContext(Dispatchers.IO) { FileOps.findDuplicates(files) { isActive } }
            _dupGroups.value = groups
            dupBusy.value = false
        }
    }

    /** Ticks every copy except the oldest one in each group. */
    fun autoSelectDuplicates() {
        val groups = _dupGroups.value ?: return
        dupSelected.value = groups.flatMap { it.items.drop(1) }.map { it.path }.toSet()
    }

    fun clearDuplicateSelection() { dupSelected.value = emptySet() }

    fun toggleDuplicate(path: String) {
        val groups = _dupGroups.value ?: return
        val current = dupSelected.value
        if (path in current) {
            dupSelected.value = current - path
            return
        }
        val group = groups.firstOrNull { g -> g.items.any { it.path == path } } ?: return
        val alreadyTicked = group.items.count { it.path in current }
        if (alreadyTicked + 1 >= group.items.size) {
            _messages.tryEmit("Keep at least one copy of each file")
            return
        }
        dupSelected.value = current + path
    }

    fun deleteSelectedDuplicates() {
        val groups = _dupGroups.value ?: return
        val paths = dupSelected.value
        val items = groups.flatMap { it.items }.filter { it.path in paths }
        if (items.isEmpty()) return
        dupSelected.value = emptySet()
        _dupGroups.value = groups
            .map { g -> DuplicateGroup(g.size, g.items.filter { it.path !in paths }) }
            .filter { it.items.size > 1 }
        runOp(
            "Moving to Recycle bin…",
            "Moved ${items.size} duplicate${if (items.size == 1) "" else "s"} to Recycle bin",
        ) {
            for (item in items) trash(File(item.path))
        }
    }

    // ---- secure folder -------------------------------------------------------------------

    val hasPin = MutableStateFlow(securePrefs.contains("hash"))
    val secureUnlocked = MutableStateFlow(false)
    val secureEntries = MutableStateFlow<List<VaultEntry>>(emptyList())
    private var failedAttempts = 0
    private var lockedUntil = 0L

    fun refreshSecure() {
        viewModelScope.launch {
            secureEntries.value = withContext(Dispatchers.IO) {
                runCatching { secureVault.list() }.getOrDefault(emptyList()).sortedByDescending { it.deletedAt }
            }
        }
    }

    fun setPin(pin: String) {
        val salt = UUID.randomUUID().toString()
        securePrefs.edit().putString("salt", salt).putString("hash", hashPin(salt, pin)).apply()
        hasPin.value = true
        secureUnlocked.value = true
    }

    /** Returns null when unlocked, or a message to show. */
    fun unlockWithPin(pin: String): String? {
        val now = System.currentTimeMillis()
        if (now < lockedUntil) return "Too many attempts. Try again in ${(lockedUntil - now) / 1000 + 1}s"
        val salt = securePrefs.getString("salt", "") ?: ""
        val expected = securePrefs.getString("hash", "") ?: ""
        if (expected.isNotEmpty() && hashPin(salt, pin) == expected) {
            failedAttempts = 0
            secureUnlocked.value = true
            return null
        }
        failedAttempts++
        if (failedAttempts >= 5) {
            failedAttempts = 0
            lockedUntil = now + 30_000L
            return "Too many attempts. Try again in 30s"
        }
        return "Wrong PIN"
    }

    fun unlockWithDevice() { secureUnlocked.value = true }
    fun lockSecure() { secureUnlocked.value = false }

    fun moveToSecure(items: List<FileItem>) {
        val n = items.size
        runOp("Moving to Secure folder…", "Moved $n item${if (n == 1) "" else "s"} to Secure folder") {
            for (item in items) {
                secureVault.add(File(item.path))
                favStore.remove(item.path)
            }
        }
    }

    fun moveOutOfSecure(entries: List<VaultEntry>) {
        runOp("Moving out…", "Moved out of Secure folder") {
            for (e in entries) secureVault.restore(e, File(downloadsPath()))
        }
    }

    fun deleteFromSecure(entries: List<VaultEntry>) {
        runOp("Deleting…", "Deleted forever") {
            for (e in entries) secureVault.deleteForever(e)
        }
    }

    // ---- text editor ---------------------------------------------------------------------

    fun openEditor(item: FileItem) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { FileOps.readText(File(item.path)) } }
            result
                .onSuccess { editor.value = EditorState(item.path, item.name, it) }
                .onFailure { _messages.tryEmit(it.message ?: "Couldn't open this file") }
        }
    }

    fun closeEditor() { editor.value = null }

    fun saveText(path: String, text: String, onSaved: () -> Unit) {
        viewModelScope.launch {
            val error = withContext(Dispatchers.IO) {
                runCatching { File(path).writeText(text) }.exceptionOrNull()
            }
            if (error == null) {
                _messages.tryEmit("Saved")
                loadDir()
                onSaved()
            } else {
                _messages.tryEmit("Couldn't save: ${error.message ?: "unknown error"}")
            }
        }
    }

    // ---- helpers -------------------------------------------------------------------------

    private fun runOp(busyMessage: String, doneMessage: String, block: () -> Unit) {
        viewModelScope.launch {
            busy.value = busyMessage
            val error = withContext(Dispatchers.IO) {
                try {
                    block()
                    null
                } catch (e: Exception) {
                    e.message ?: "Something went wrong"
                }
            }
            busy.value = null
            clearSelection()
            loadDir()
            rescan()
            updateStorage()
            refreshTrash()
            refreshSecure()
            _messages.tryEmit(if (error != null) "Failed: $error" else doneMessage)
        }
    }

    private fun computeVisible(
        s: UiState,
        dir: List<FileItem>,
        all: List<FileItem>,
        favs: Set<String>,
    ): List<FileItem> {
        val category = s.category
        var keepOrder = false
        var list: List<FileItem> = when (s.tab) {
            NavTab.Browse -> dir
            NavTab.Favourites -> favs.mapNotNull { p ->
                File(p).takeIf { it.exists() }?.toFileItem()
            }

            NavTab.Recent -> {
                keepOrder = true
                all.filter { !it.isDir }.sortedByDescending { it.modified }.take(300)
            }

            NavTab.Home -> when {
                s.largeFiles -> {
                    keepOrder = true
                    all.filter { !it.isDir }.sortedByDescending { it.size }.take(100)
                }

                category != null -> all.filter { !it.isDir && it.type == category }
                s.searching && s.query.isNotBlank() -> all
                else -> emptyList()
            }
        }
        if (s.filter != null && category == null) {
            list = list.filter { it.type == s.filter }
        }
        val q = s.query.trim()
        if (q.isNotEmpty()) {
            list = list.filter { it.name.contains(q, ignoreCase = true) }
        }
        return if (keepOrder) list else sortItems(list, s.sortField, s.ascending)
    }

    companion object {
        const val TRASH_DAYS = 30
    }
}
