package com.clearfiles.app.data

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.Properties
import java.util.UUID

/** A file or folder kept inside a [Vault] (used by the Recycle bin and the Secure folder). */
data class VaultEntry(
    val id: String,
    val name: String,
    val originalPath: String,
    val deletedAt: Long,
    val isDir: Boolean,
    val size: Long,
    val storedPath: String,
    val vaultDir: String,
)

/** Lets a stored entry be shown/opened like a normal file. */
fun VaultEntry.asFileItem(): FileItem {
    val extension = if (isDir) "" else File(name).extension.lowercase()
    return FileItem(
        path = storedPath,
        name = name,
        isDir = isDir,
        size = size,
        modified = deletedAt,
        ext = extension,
        type = if (isDir) FileType.Folder else typeForExtension(extension),
        childCount = 0,
    )
}

fun hashPin(salt: String, pin: String): String {
    val digest = MessageDigest.getInstance("SHA-256").digest("$salt:$pin".toByteArray(Charsets.UTF_8))
    return digest.joinToString("") { "%02x".format(it) }
}

/**
 * A folder that holds removed items together with a small info file (original place, date).
 * Layout:  files/<id>/<original name>   and   info/<id>.properties
 */
class Vault(private val dir: File) {
    private val filesDir: File get() = File(dir, "files")
    private val infoDir: File get() = File(dir, "info")

    fun add(src: File, now: Long = System.currentTimeMillis()): VaultEntry {
        val id = UUID.randomUUID().toString()
        val isDir = src.isDirectory
        val size = if (isDir) FileOps.folderStats(src).first else src.length()
        val holder = File(filesDir, id)
        val stored = File(holder, src.name)
        holder.mkdirs()
        infoDir.mkdirs()
        val entry = VaultEntry(id, src.name, src.path, now, isDir, size, stored.path, dir.path)
        try {
            FileOps.move(src, stored)
        } catch (e: Exception) {
            holder.deleteRecursively()
            throw e
        }
        val props = Properties()
        props.setProperty("name", entry.name)
        props.setProperty("originalPath", entry.originalPath)
        props.setProperty("deletedAt", entry.deletedAt.toString())
        props.setProperty("isDir", entry.isDir.toString())
        props.setProperty("size", entry.size.toString())
        FileOutputStream(File(infoDir, "$id.properties")).use { props.store(it, null) }
        return entry
    }

    fun list(): List<VaultEntry> {
        val infos = infoDir.listFiles { f -> f.name.endsWith(".properties") } ?: return emptyList()
        val out = ArrayList<VaultEntry>()
        for (f in infos) {
            try {
                val p = Properties()
                FileInputStream(f).use { p.load(it) }
                val id = f.name.removeSuffix(".properties")
                val name = p.getProperty("name") ?: continue
                val stored = File(File(filesDir, id), name)
                if (!stored.exists()) {
                    f.delete()
                    continue
                }
                out.add(
                    VaultEntry(
                        id = id,
                        name = name,
                        originalPath = p.getProperty("originalPath") ?: "",
                        deletedAt = p.getProperty("deletedAt")?.toLongOrNull() ?: 0L,
                        isDir = p.getProperty("isDir") == "true",
                        size = p.getProperty("size")?.toLongOrNull() ?: 0L,
                        storedPath = stored.path,
                        vaultDir = dir.path,
                    ),
                )
            } catch (e: Exception) {
                // skip unreadable info files
            }
        }
        return out
    }

    /** Puts the item back where it came from (or into [fallbackDir]). Returns the restored file. */
    fun restore(entry: VaultEntry, fallbackDir: File): File {
        val parent = File(entry.originalPath).parentFile
        val destDir = if (parent != null && (parent.isDirectory || parent.mkdirs())) parent else fallbackDir
        destDir.mkdirs()
        val target = FileOps.uniqueFile(destDir, entry.name)
        FileOps.move(File(entry.storedPath), target)
        remove(entry)
        return target
    }

    fun deleteForever(entry: VaultEntry) = remove(entry)

    /** Removes everything older than [cutoff] (milliseconds since 1970). Returns how many were removed. */
    fun purgeOlderThan(cutoff: Long): Int {
        val old = list().filter { it.deletedAt < cutoff }
        old.forEach { remove(it) }
        return old.size
    }

    private fun remove(entry: VaultEntry) {
        File(filesDir, entry.id).deleteRecursively()
        File(infoDir, "${entry.id}.properties").delete()
    }
}
