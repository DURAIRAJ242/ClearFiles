@file:OptIn(ExperimentalMaterial3Api::class)

package com.clearfiles.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.clearfiles.app.data.FileType
import com.clearfiles.app.data.StorageBreakdown
import com.clearfiles.app.util.formatSize
import kotlin.math.roundToInt

private data class Segment(val label: String, val bytes: Long, val color: Color)

@Composable
fun StorageDetailScreen(
    b: StorageBreakdown?,
    snackbar: SnackbarHostState,
    onClose: () -> Unit,
    onBrowse: () -> Unit,
    onDuplicates: () -> Unit,
    onLargeFiles: () -> Unit,
) {
    BackHandler(onBack = onClose)

    OverlayScaffold(b?.root?.name ?: "Storage", onClose, snackbar) { padding ->
        if (b == null) {
            EmptyState(Icons.Rounded.Storage, "Storage not available", "This storage is no longer connected.", Modifier.padding(padding))
        } else {
            val parts = listOf(
                FileType.Image, FileType.Video, FileType.Audio, FileType.Document,
                FileType.Archive, FileType.Apk, FileType.Other,
            ).map { Segment(it.label, b.byType[it] ?: 0L, typeColor(it)) } +
                Segment("System & apps", b.systemBytes, Color(0xFF94A3B8))

            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        formatSize(b.used),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        "  used of ${formatSize(b.total)}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 4.dp),
                    )
                }

                // Coloured bar: one piece per file type, grey = free space.
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(18.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    parts.filter { it.bytes > 0 }.forEach { seg ->
                        Box(
                            Modifier
                                .weight(seg.bytes.toFloat())
                                .fillMaxHeight()
                                .background(seg.color),
                        )
                    }
                    if (b.free > 0) {
                        Box(Modifier.weight(b.free.toFloat()).fillMaxHeight())
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    parts.forEach { seg ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier
                                    .size(12.dp)
                                    .background(seg.color, CircleShape),
                            )
                            Text(
                                "  ${seg.label}",
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f),
                            )
                            val percent = if (b.total > 0) (seg.bytes * 100f / b.total).roundToInt() else 0
                            Text(
                                "${formatSize(seg.bytes)}  ·  $percent%",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(12.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
                        )
                        Text(
                            "  Free",
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f),
                        )
                        Text(
                            formatSize(b.free),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                Spacer(Modifier.height(4.dp))
                Button(onClick = onBrowse, modifier = Modifier.fillMaxWidth()) { Text("Browse files") }
                OutlinedButton(onClick = onDuplicates, modifier = Modifier.fillMaxWidth()) {
                    Text("Find duplicate files")
                }
                OutlinedButton(onClick = onLargeFiles, modifier = Modifier.fillMaxWidth()) {
                    Text("Show large files")
                }
            }
        }
    }
}
