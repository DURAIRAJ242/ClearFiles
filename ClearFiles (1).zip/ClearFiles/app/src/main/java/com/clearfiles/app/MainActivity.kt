package com.clearfiles.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.clearfiles.app.data.Screen
import com.clearfiles.app.ui.DuplicatesScreen
import com.clearfiles.app.ui.MainScreen
import com.clearfiles.app.ui.RecycleBinScreen
import com.clearfiles.app.ui.SecureScreen
import com.clearfiles.app.ui.StorageDetailScreen
import com.clearfiles.app.ui.TextEditorScreen
import com.clearfiles.app.ui.theme.FilesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FilesTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot()
                }
            }
        }
    }
}

private fun hasAllFilesAccess(): Boolean =
    Build.VERSION.SDK_INT < Build.VERSION_CODES.R || Environment.isExternalStorageManager()

@Composable
private fun AppRoot(vm: FilesViewModel = viewModel()) {
    val ctx = LocalContext.current
    var hasAccess by remember { mutableStateOf(hasAllFilesAccess()) }

    // Re-check when coming back from the Android settings screen.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        hasAccess = hasAllFilesAccess()
        if (hasAccess) vm.onResume()
    }
    LaunchedEffect(hasAccess) { if (hasAccess) vm.start() }

    if (!hasAccess) {
        PermissionScreen(
            onAllow = {
                try {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:${ctx.packageName}"),
                        ),
                    )
                } catch (e: Exception) {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            },
        )
        return
    }

    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(it) } }

    val editor by vm.editor.collectAsStateWithLifecycle()
    val screen by vm.screen.collectAsStateWithLifecycle()
    val detailRoot by vm.detailRoot.collectAsStateWithLifecycle()
    val breakdowns by vm.breakdowns.collectAsStateWithLifecycle()

    // Relock the Secure folder whenever the app leaves the foreground.
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.lockSecure() }

    Box(Modifier.fillMaxSize()) {
        MainScreen(vm, snackbar)
        when (screen) {
            Screen.Duplicates -> DuplicatesScreen(vm, snackbar, onClose = vm::closeScreen)
            Screen.RecycleBin -> RecycleBinScreen(vm, snackbar, onClose = vm::closeScreen)
            Screen.Secure -> SecureScreen(vm, snackbar, onClose = vm::closeScreen)
            Screen.StorageDetail -> {
                val root = detailRoot
                StorageDetailScreen(
                    b = breakdowns.firstOrNull { it.root.path == root?.path },
                    snackbar = snackbar,
                    onClose = vm::closeScreen,
                    onBrowse = {
                        vm.closeScreen()
                        root?.let { vm.openFolder(it.path) }
                    },
                    onDuplicates = {
                        vm.closeScreen()
                        vm.openScreen(Screen.Duplicates)
                    },
                    onLargeFiles = {
                        vm.closeScreen()
                        vm.openLargeFiles()
                    },
                )
            }
            null -> {}
        }
        editor?.let { state ->
            TextEditorScreen(
                state = state,
                onClose = vm::closeEditor,
                onSave = { text, onSaved -> vm.saveText(state.path, text, onSaved) },
            )
        }
    }
}

@Composable
private fun PermissionScreen(onAllow: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.background),
                ),
            ),
    ) {
        Column(
            Modifier
                .align(Alignment.Center)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Box(
                Modifier
                    .size(96.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Rounded.Folder,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(48.dp),
                )
            }
            Text("Clear Files", style = MaterialTheme.typography.headlineMedium)
            Text(
                "To show and manage every file on your phone, Android needs you to turn on " +
                    "“Allow access to manage all files” for this app.",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    Icons.Rounded.Lock,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(18.dp),
                )
                Text(
                    "No ads. No tracking. The app has no internet permission, so your files never leave this phone.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Button(onClick = onAllow, modifier = Modifier.padding(top = 8.dp)) { Text("Open settings") }
            Text(
                "Turn the switch on, then press back to return here.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
        }
    }
}
