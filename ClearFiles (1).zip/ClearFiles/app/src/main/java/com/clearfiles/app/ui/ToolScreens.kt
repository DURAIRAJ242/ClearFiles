@file:OptIn(ExperimentalMaterial3Api::class)

package com.clearfiles.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clearfiles.app.FilesViewModel
import com.clearfiles.app.data.DuplicateGroup
import com.clearfiles.app.data.FileItem
import com.clearfiles.app.data.VaultEntry
import com.clearfiles.app.data.asFileItem
import com.clearfiles.app.util.formatSize
import com.clearfiles.app.util.shortDate
import java.io.File

// =============================================================================================
// Duplicate files
// =============================================================================================

@Composable
fun DuplicatesScreen(vm: FilesViewModel, snackbar: SnackbarHostState, onClose: () -> Unit) {
    val groups by vm.dupGroups.collectAsStateWithLifecycle()
    val busy by vm.dupBusy.collectAsStateWithLifecycle()
    val selected by vm.dupSelected.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }

    BackHandler(onBack = onClose)

    val g = groups
    val selectedBytes = remember(g, selected) {
        g?.sumOf { grp -> grp.items.count { it.path in selected }.toLong() * grp.size } ?: 0L
    }
    val reclaimable = remember(g) { g?.sumOf { it.wasted } ?: 0L }

    OverlayScaffold(
        title = "Duplicate files",
        onClose = onClose,
        snackbar = snackbar,
        actions = {
            IconButton(onClick = vm::analyzeDuplicates, enabled = !busy) {
                Icon(Icons.Rounded.Refresh, "Analyze again")
            }
        },
        bottomBar = {
            if (selected.isNotEmpty()) {
                BottomActionBar {
                    Button(onClick = { confirm = true }, modifier = Modifier.weight(1f)) {
                        Text("Move ${selected.size} to Recycle bin · ${formatSize(selectedBytes)}")
                    }
                }
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (g == null || busy) {
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    CircularProgressIndicator()
                    Text(
                        "Looking for duplicate files…",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 20.dp),
                    )
                    Text(
                        "This can take a minute on a full phone.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            } else if (g.isEmpty()) {
                EmptyState(Icons.Rounded.CheckCircle, "No duplicates found", "Every file on your phone is unique.")
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                    item {
                        SummaryCard(
                            groups = g.size,
                            reclaimable = reclaimable,
                            onAuto = vm::autoSelectDuplicates,
                            onClear = vm::clearDuplicateSelection,
                        )
                    }
                    g.forEachIndexed { gi, group ->
                        item(key = "h$gi") { GroupHeader(group) }
                        items(group.items, key = { "r$gi|${it.path}" }) { f ->
                            DuplicateRow(f, f.path in selected) { vm.toggleDuplicate(f.path) }
                        }
                    }
                }
            }
        }
    }

    if (confirm) {
        ConfirmDialog(
            title = "Move ${selected.size} file${if (selected.size == 1) "" else "s"} to Recycle bin?",
            message = "One copy of every file is kept. You can restore these from the Recycle bin for 30 days.",
            confirmText = "Move",
            onConfirm = {
                confirm = false
                vm.deleteSelectedDuplicates()
            },
            onDismiss = { confirm = false },
        )
    }
}

@Composable
private fun SummaryCard(groups: Int, reclaimable: Long, onAuto: () -> Unit, onClear: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        shape = RoundedCornerShape(22.dp),
        color = Color.Transparent,
    ) {
        Column(
            Modifier
                .background(Brush.linearGradient(listOf(Color(0xFFEC4899), Color(0xFF7C4DFF))))
                .padding(20.dp),
        ) {
            Text(
                formatSize(reclaimable),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium,
            )
            Text(
                "can be freed · $groups group${if (groups == 1) "" else "s"} of identical files",
                color = Color(0xE6FFFFFF),
                style = MaterialTheme.typography.bodyMedium,
            )
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onAuto) { Text("Auto-select extras") }
                TextButton(onClick = onClear) { Text("Clear", color = Color.White) }
            }
            Text(
                "Auto-select keeps the oldest copy of each file.",
                color = Color(0xCCFFFFFF),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

@Composable
private fun GroupHeader(group: DuplicateGroup) {
    Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 2.dp)) {
        Text(
            group.items.first().name,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            "${group.items.size} copies · ${formatSize(group.size)} each · ${formatSize(group.wasted)} wasted",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun DuplicateRow(item: FileItem, checked: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = null, modifier = Modifier.padding(8.dp))
        FileThumb(item.path, item.type, 42.dp)
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(item.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                (File(item.path).parent ?: "") + " · " + shortDate(item.modified),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// =============================================================================================
// Recycle bin
// =============================================================================================

private enum class TrashConfirm { Selected, Empty }

@Composable
fun RecycleBinScreen(vm: FilesViewModel, snackbar: SnackbarHostState, onClose: () -> Unit) {
    val entries by vm.trashEntries.collectAsStateWithLifecycle()
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var confirm by remember { mutableStateOf<TrashConfirm?>(null) }

    BackHandler(onBack = onClose)

    val chosen = entries.filter { it.id in selectedIds }

    OverlayScaffold(
        title = "Recycle bin",
        onClose = onClose,
        snackbar = snackbar,
        actions = {
            if (entries.isNotEmpty()) {
                IconButton(onClick = {
                    selectedIds = if (chosen.size == entries.size) emptySet() else entries.map { it.id }.toSet()
                }) { Icon(Icons.Rounded.SelectAll, "Select all") }
                TextButton(onClick = { confirm = TrashConfirm.Empty }) { Text("Empty") }
            }
        },
        bottomBar = {
            if (chosen.isNotEmpty()) {
                BottomActionBar {
                    Button(
                        onClick = {
                            vm.restoreFromTrash(chosen)
                            selectedIds = emptySet()
                        },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Rounded.Restore, contentDescription = null)
                        Text("  Restore")
                    }
                    OutlinedButton(
                        onClick = { confirm = TrashConfirm.Selected },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = null)
                        Text("  Delete forever")
                    }
                }
            }
        },
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState(
                Icons.Rounded.Delete,
                "Recycle bin is empty",
                "Deleted files wait here for 30 days so you can restore them.",
                Modifier.padding(padding),
            )
        } else {
            LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(bottom = 24.dp)) {
                item {
                    NoteCard(
                        "Items are removed for good after 30 days. Tap an item to select it.",
                        Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
                items(entries, key = { it.id }) { e ->
                    TrashRow(e, e.id in selectedIds) {
                        selectedIds = if (e.id in selectedIds) selectedIds - e.id else selectedIds + e.id
                    }
                }
            }
        }
    }

    when (confirm) {
        TrashConfirm.Selected -> ConfirmDialog(
            title = "Delete forever?",
            message = "${chosen.size} item${if (chosen.size == 1) "" else "s"} will be permanently deleted. This can't be undone.",
            confirmText = "Delete",
            onConfirm = {
                confirm = null
                vm.deleteFromTrashForever(chosen)
                selectedIds = emptySet()
            },
            onDismiss = { confirm = null },
        )

        TrashConfirm.Empty -> ConfirmDialog(
            title = "Empty Recycle bin?",
            message = "All ${entries.size} items will be permanently deleted. This can't be undone.",
            confirmText = "Empty",
            onConfirm = {
                confirm = null
                vm.emptyTrash()
                selectedIds = emptySet()
            },
            onDismiss = { confirm = null },
        )

        null -> {}
    }
}

@Composable
private fun TrashRow(entry: VaultEntry, checked: Boolean, onToggle: () -> Unit) {
    val item = entry.asFileItem()
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = null, modifier = Modifier.padding(8.dp))
        FileThumb(item.path, item.type, 46.dp)
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(entry.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${formatSize(entry.size)} · Deleted ${shortDate(entry.deletedAt)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                "From ${File(entry.originalPath).parent ?: ""}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
