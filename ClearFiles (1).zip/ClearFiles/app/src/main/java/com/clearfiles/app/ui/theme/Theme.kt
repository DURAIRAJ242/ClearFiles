package com.clearfiles.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Heart colour for favourites. */
val FavoriteRed = Color(0xFFFF4D79)

private val LightColors = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE7FF),
    onPrimaryContainer = Color(0xFF0B2A6B),
    secondary = Color(0xFF0EA5A4),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD2F3F2),
    onSecondaryContainer = Color(0xFF00403F),
    tertiary = Color(0xFFF5A623),
    background = Color(0xFFF5F7FB),
    onBackground = Color(0xFF13161F),
    surface = Color.White,
    onSurface = Color(0xFF13161F),
    surfaceVariant = Color(0xFFE8ECF5),
    onSurfaceVariant = Color(0xFF4B5468),
    outline = Color(0xFF8A90A6),
    outlineVariant = Color(0xFFD8DCEA),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF9FAFE),
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color(0xFFF0F2FA),
    surfaceContainerHighest = Color(0xFFE8ECF5),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8DB3FF),
    onPrimary = Color(0xFF0A2463),
    primaryContainer = Color(0xFF1E3E94),
    onPrimaryContainer = Color(0xFFDCE7FF),
    secondary = Color(0xFF4FD6D4),
    onSecondary = Color(0xFF00403F),
    secondaryContainer = Color(0xFF0C5755),
    onSecondaryContainer = Color(0xFFD2F3F2),
    tertiary = Color(0xFFFFC15A),
    background = Color(0xFF0C0F15),
    onBackground = Color(0xFFE6E8F2),
    surface = Color(0xFF12161E),
    onSurface = Color(0xFFE6E8F2),
    surfaceVariant = Color(0xFF232733),
    onSurfaceVariant = Color(0xFFB1B6CC),
    outline = Color(0xFF6E7391),
    outlineVariant = Color(0xFF2E3243),
    surfaceContainerLowest = Color(0xFF0A0C10),
    surfaceContainerLow = Color(0xFF12161E),
    surfaceContainer = Color(0xFF171B24),
    surfaceContainerHigh = Color(0xFF1E232E),
    surfaceContainerHighest = Color(0xFF262B37),
)

private val AppTypography = Typography().let { base ->
    base.copy(
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.Bold, fontSize = 22.sp),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        titleSmall = base.titleSmall.copy(fontWeight = FontWeight.SemiBold),
    )
}

@Composable
fun FilesTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
