@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.clearfiles.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.clearfiles.app.data.FileItem
import com.clearfiles.app.data.FileOps
import com.clearfiles.app.data.FileType
import com.clearfiles.app.data.NavTab
import com.clearfiles.app.data.SortField
import com.clearfiles.app.data.UiState
import com.clearfiles.app.util.formatSize
import com.clearfiles.app.util.fullDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ---- dialogs ---------------------------------------------------------------------------------

@Composable
fun TextInputDialog(
    title: String,
    label: String,
    initial: String,
    confirmText: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var value by remember {
        mutableStateOf(
            TextFieldValue(initial, selection = TextRange(0, initial.substringBeforeLast('.', initial).length)),
        )
    }
    val focus = remember { FocusRequester() }
    val error = if (value.text.isEmpty()) null else FileOps.validateName(value.text)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                label = { Text(label) },
                singleLine = true,
                isError = error != null,
                supportingText = { if (error != null) Text(error) },
                modifier = Modifier.focusRequester(focus),
            )
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(value.text.trim()) },
                enabled = value.text.isNotBlank() && FileOps.validateName(value.text) == null,
            ) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(message) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(confirmText, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun DetailsDialog(item: FileItem, onClose: () -> Unit) {
    val folderStats by produceState<Pair<Long, Int>?>(null, item.path) {
        value = if (item.isDir) {
            withContext(Dispatchers.IO) { FileOps.folderStats(File(item.path)) }
        } else {
            null
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } },
        title = { Text("Details") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                InfoRow("Name", item.name)
                InfoRow("Location", File(item.path).parent ?: "")
                InfoRow("Type", if (item.isDir) "Folder" else item.type.label.removeSuffix("s"))
                if (item.isDir) {
                    val stats = folderStats
                    InfoRow("Size", if (stats != null) formatSize(stats.first) else "Calculating…")
                    InfoRow("Contains", if (stats != null) "${stats.second} files" else "Calculating…")
                } else {
                    InfoRow("Size", "${formatSize(item.size)} (${item.size} bytes)")
                }
                InfoRow("Modified", fullDate(item.modified))
            }
        },
    )
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

// ---- bottom sheets ---------------------------------------------------------------------------

@Composable
fun SortSheet(ui: UiState, onSort: (SortField, Boolean) -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 20.dp),
        ) {
            Text("Sort by", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            SortField.entries.forEach { field ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSort(field, ui.ascending) }
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = ui.sortField == field, onClick = { onSort(field, ui.ascending) })
                    Text(field.label, style = MaterialTheme.typography.bodyLarge)
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Order", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = ui.ascending,
                    onClick = { onSort(ui.sortField, true) },
                    label = { Text(if (ui.sortField == SortField.Date) "Oldest first" else if (ui.sortField == SortField.Size) "Smallest first" else "A to Z") },
                )
                FilterChip(
                    selected = !ui.ascending,
                    onClick = { onSort(ui.sortField, false) },
                    label = { Text(if (ui.sortField == SortField.Date) "Newest first" else if (ui.sortField == SortField.Size) "Largest first" else "Z to A") },
                )
            }
            Text(
                "Folders always stay at the top.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 10.dp),
            )
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.End) {
                Button(onClick = onDismiss) { Text("Done") }
            }
        }
    }
}

@Composable
fun FilterSheet(
    ui: UiState,
    onFilter: (FileType?) -> Unit,
    onShowHidden: (Boolean) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 20.dp),
        ) {
            Text("Filter", style = MaterialTheme.typography.titleLarge)
            Text(
                "Show only",
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = ui.filter == null,
                    onClick = { onFilter(null) },
                    label = { Text("All") },
                )
                FileType.entries.forEach { type ->
                    FilterChip(
                        selected = ui.filter == type,
                        onClick = { onFilter(type) },
                        label = { Text(type.label) },
                    )
                }
            }
            if (ui.tab == NavTab.Browse) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Show hidden files", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "Files and folders starting with a dot",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = ui.showHidden, onCheckedChange = onShowHidden)
                }
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = { onFilter(null) }) { Text("Reset") }
                Spacer(Modifier.weight(1f))
                Button(onClick = onDismiss) { Text("Done") }
            }
        }
    }
}

@Composable
fun CreateSheet(onNewFolder: () -> Unit, onNewFile: () -> Unit, onDismiss: () -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Column(
            Modifier
                .navigationBarsPadding()
                .padding(bottom = 16.dp),
        ) {
            Text(
                "Create new",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(start = 20.dp, bottom = 8.dp),
            )
            ListItem(
                headlineContent = { Text("Folder") },
                leadingContent = { Icon(Icons.Rounded.CreateNewFolder, null, tint = typeColor(FileType.Folder)) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                modifier = Modifier.clickable(onClick = onNewFolder),
            )
            ListItem(
                headlineContent = { Text("Text file") },
                leadingContent = { Icon(Icons.Rounded.NoteAdd, null, tint = typeColor(FileType.Document)) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                modifier = Modifier.clickable(onClick = onNewFile),
            )
            Spacer(Modifier.size(4.dp))
        }
    }
}
