@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.clearfiles.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clearfiles.app.FilesViewModel
import com.clearfiles.app.data.Clip
import com.clearfiles.app.data.FileItem
import com.clearfiles.app.data.NavTab
import com.clearfiles.app.data.Screen
import com.clearfiles.app.data.StorageRoot
import com.clearfiles.app.data.UiState
import com.clearfiles.app.data.isEditable
import com.clearfiles.app.util.downloadsPath
import com.clearfiles.app.util.openFile
import com.clearfiles.app.util.shareFiles
import java.io.File
import kotlinx.coroutines.launch

private sealed interface FileDialog {
    data class Rename(val item: FileItem) : FileDialog
    data object NewFolder : FileDialog
    data object NewFile : FileDialog
    data class Delete(val items: List<FileItem>) : FileDialog
    data class Details(val item: FileItem) : FileDialog
    data class Extract(val item: FileItem) : FileDialog
    data class Secure(val items: List<FileItem>) : FileDialog
}

@Composable
fun MainScreen(vm: FilesViewModel, snackbar: SnackbarHostState) {
    val ctx = LocalContext.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val visible by vm.visible.collectAsStateWithLifecycle()
    val favs by vm.favourites.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    val clip by vm.clipboard.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val counts by vm.counts.collectAsStateWithLifecycle()
    val recents by vm.recents.collectAsStateWithLifecycle()
    val breakdowns by vm.breakdowns.collectAsStateWithLifecycle()
    val trash by vm.trashEntries.collectAsStateWithLifecycle()
    val hasPin by vm.hasPin.collectAsStateWithLifecycle()
    val selectMode by vm.selectMode.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val scanning by vm.scanning.collectAsStateWithLifecycle()

    var showSort by remember { mutableStateOf(false) }
    var showFilter by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<FileDialog?>(null) }

    val selecting = selectMode
    val selectedItems = remember(selected, visible) { visible.filter { it.path in selected } }
    val isDashboard = ui.tab == NavTab.Home && ui.category == null && !ui.largeFiles && !ui.searching
    val canGoBack = ui.tab != NavTab.Home || ui.category != null || ui.largeFiles

    BackHandler(enabled = selecting) { vm.clearSelection() }
    BackHandler(enabled = !selecting && ui.searching) { vm.closeSearch() }
    BackHandler(enabled = !selecting && !ui.searching && canGoBack) { vm.back() }

    fun openItem(item: FileItem) {
        when {
            item.isDir -> vm.openFolder(item.path)
            item.isEditable -> vm.openEditor(item)
            item.ext == "zip" -> dialog = FileDialog.Extract(item)
            else -> openFile(ctx, item)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            when {
                selecting -> {
                    val allFav = selectedItems.isNotEmpty() && selectedItems.all { it.path in favs }
                    TopAppBar(
                        title = {
                            Text(
                                if (selected.isEmpty()) "Select items" else "${selected.size} selected",
                                style = MaterialTheme.typography.titleLarge,
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = vm::clearSelection) { Icon(Icons.Rounded.Close, "Cancel") }
                        },
                        actions = {
                            IconButton(onClick = vm::toggleSelectAll) { Icon(Icons.Rounded.SelectAll, "Select all") }
                            IconButton(onClick = { vm.setFavourites(selectedItems, !allFav) }, enabled = selectedItems.isNotEmpty()) {
                                Icon(
                                    if (allFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                    "Favourite",
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            navigationIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            actionIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        ),
                    )
                }

                ui.searching -> SearchTopBar(
                    query = ui.query,
                    placeholder = if (ui.tab == NavTab.Browse) "Search in this folder" else "Search all files",
                    onQuery = vm::setQuery,
                    onClose = vm::closeSearch,
                )

                else -> {
                    val title = when {
                        ui.tab == NavTab.Home && ui.largeFiles -> "Large files"
                        ui.tab == NavTab.Home && ui.category != null -> ui.category?.label ?: "Files"
                        ui.tab == NavTab.Recent -> "Recent"
                        ui.tab == NavTab.Home -> "Clear Files"
                        ui.tab == NavTab.Favourites -> "Favourites"
                        else -> {
                            val root = vm.rootFor(ui.dir)
                            if (ui.dir == root.path) root.name else File(ui.dir).name
                        }
                    }
                    var menu by remember { mutableStateOf(false) }
                    TopAppBar(
                        title = {
                            Column {
                                Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (!isDashboard) {
                                    Text(
                                        "${visible.size} item${if (visible.size == 1) "" else "s"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        },
                        navigationIcon = {
                            if (canGoBack) {
                                IconButton(onClick = vm::back) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
                            }
                        },
                        actions = {
                            IconButton(onClick = vm::openSearch) { Icon(Icons.Rounded.Search, "Search") }
                            if (!isDashboard && visible.isNotEmpty()) {
                                IconButton(onClick = vm::startSelect) { Icon(Icons.Rounded.DoneAll, "Select multiple") }
                            }
                            if (ui.tab == NavTab.Browse) {
                                IconButton(onClick = { vm.setShowHidden(!ui.showHidden) }) {
                                    Icon(
                                        if (ui.showHidden) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                        if (ui.showHidden) "Hide hidden files" else "Show hidden files",
                                    )
                                }
                            }
                            Box {
                                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                    if (!isDashboard && ui.tab != NavTab.Recent && !ui.largeFiles) {
                                        DropdownMenuItem(
                                            text = { Text("Sort by") },
                                            leadingIcon = { Icon(Icons.AutoMirrored.Rounded.Sort, null) },
                                            onClick = {
                                                menu = false
                                                showSort = true
                                            },
                                        )
                                    }
                                    if (!isDashboard && ui.category == null) {
                                        DropdownMenuItem(
                                            text = { Text(if (ui.filter != null) "Filter (on)" else "Filter") },
                                            leadingIcon = { Icon(Icons.Rounded.FilterList, null) },
                                            onClick = {
                                                menu = false
                                                showFilter = true
                                            },
                                        )
                                    }
                                    DropdownMenuItem(
                                        text = { Text("Refresh") },
                                        leadingIcon = { Icon(Icons.Rounded.Refresh, null) },
                                        onClick = {
                                            menu = false
                                            vm.loadDir()
                                            vm.rescan()
                                        },
                                    )
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                    )
                }
            }
        },
        bottomBar = {
            Column {
                val c = clip
                if (c != null && ui.tab == NavTab.Browse && !selecting) {
                    PasteBar(c, onPaste = vm::paste, onCancel = vm::clearClipboard)
                }
                if (selecting) {
                    SelectionBar(
                        items = selectedItems,
                        onSecure = {
                            if (!hasPin) vm.openScreen(Screen.Secure) else dialog = FileDialog.Secure(selectedItems)
                        },
                        onCopy = { vm.copyToClipboard(selectedItems, cut = false) },
                        onMove = { vm.copyToClipboard(selectedItems, cut = true) },
                        onDelete = { dialog = FileDialog.Delete(selectedItems) },
                        onShare = { shareFiles(ctx, selectedItems) },
                        onRename = { selectedItems.firstOrNull()?.let { dialog = FileDialog.Rename(it) } },
                        onCompress = { vm.compress(selectedItems) },
                        onDetails = { selectedItems.firstOrNull()?.let { dialog = FileDialog.Details(it) } },
                    )
                } else {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                        val tabs = listOf(
                            Triple(NavTab.Home, "Home", Icons.Rounded.Home),
                            Triple(NavTab.Recent, "Recent", Icons.Rounded.History),
                            Triple(NavTab.Browse, "Browse", Icons.Rounded.Folder),
                            Triple(NavTab.Favourites, "Favourites", Icons.Rounded.Favorite),
                        )
                        tabs.forEach { (tab, label, icon) ->
                            NavigationBarItem(
                                selected = ui.tab == tab,
                                onClick = { vm.setTab(tab) },
                                icon = { Icon(icon, label) },
                                label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                ),
                            )
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (ui.tab == NavTab.Browse && !selecting && !ui.searching) {
                FloatingActionButton(
                    onClick = { showCreate = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ) { Icon(Icons.Rounded.Add, "Create new") }
            }
        },
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            if (isDashboard) {
                HomeContent(
                    breakdowns = breakdowns,
                    counts = counts,
                    recents = recents,
                    favCount = favs.size,
                    scanning = scanning,
                    trashCount = trash.size,
                    onSeeAllRecent = { vm.setTab(NavTab.Recent) },
                    onCategory = vm::openCategory,
                    onDownloads = { vm.openFolder(downloadsPath()) },
                    onFavourites = { vm.setTab(NavTab.Favourites) },
                    onStorage = { vm.openStorageDetail(it.root) },
                    onMissingStorage = { name -> scope.launch { snackbar.showSnackbar("$name is not available on this phone") } },
                    onDuplicates = { vm.openScreen(Screen.Duplicates) },
                    onLargeFiles = vm::openLargeFiles,
                    onTrash = { vm.openScreen(Screen.RecycleBin) },
                    onSecure = { vm.openScreen(Screen.Secure) },
                    onOpen = ::openItem,
                )
            } else {
                Column(Modifier.fillMaxSize()) {
                    if (ui.tab == NavTab.Browse && !ui.searching) {
                        BrowseHeader(vm, ui.dir, vm.roots)
                    }
                    if (ui.filter != null && ui.category == null) {
                        ActiveFilterBar(ui.filter?.label ?: "", onClear = { vm.setFilter(null) })
                    }
                    if (visible.isEmpty()) {
                        EmptyContent(ui, scanning)
                    } else {
                        LazyColumn(contentPadding = PaddingValues(bottom = 96.dp)) {
                            items(visible, key = { it.path }) { item ->
                                FileRow(
                                    item = item,
                                    favorite = item.path in favs,
                                    selected = item.path in selected,
                                    selecting = selecting,
                                    onClick = { if (selecting) vm.toggleSelect(item.path) else openItem(item) },
                                    onLongClick = { vm.toggleSelect(item.path) },
                                    onToggleFav = { vm.toggleFavourite(item.path) },
                                )
                            }
                        }
                    }
                }
            }

            if (scanning && (isDashboard || ui.category != null || ui.largeFiles || ui.tab == NavTab.Recent || ui.searching)) {
                LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
            }

            val busyText = busy
            if (busyText != null) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color(0x66000000))
                        .blockTouches(),
                    contentAlignment = Alignment.Center,
                ) {
                    Card {
                        Row(
                            Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                        ) {
                            CircularProgressIndicator(Modifier.padding(2.dp))
                            Text(busyText, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            }
        }
    }

    if (showSort) {
        SortSheet(ui, onSort = vm::setSort, onDismiss = { showSort = false })
    }
    if (showFilter) {
        FilterSheet(ui, onFilter = vm::setFilter, onShowHidden = vm::setShowHidden, onDismiss = { showFilter = false })
    }
    if (showCreate) {
        CreateSheet(
            onNewFolder = {
                showCreate = false
                dialog = FileDialog.NewFolder
            },
            onNewFile = {
                showCreate = false
                dialog = FileDialog.NewFile
            },
            onDismiss = { showCreate = false },
        )
    }

    when (val d = dialog) {
        is FileDialog.Rename -> TextInputDialog(
            title = "Rename",
            label = "Name",
            initial = d.item.name,
            confirmText = "Rename",
            onConfirm = {
                dialog = null
                vm.rename(d.item, it)
            },
            onDismiss = { dialog = null },
        )

        FileDialog.NewFolder -> TextInputDialog(
            title = "New folder",
            label = "Folder name",
            initial = "",
            confirmText = "Create",
            onConfirm = {
                dialog = null
                vm.createFolder(it)
            },
            onDismiss = { dialog = null },
        )

        FileDialog.NewFile -> TextInputDialog(
            title = "New text file",
            label = "File name",
            initial = "",
            confirmText = "Create",
            onConfirm = {
                dialog = null
                vm.createTextFile(it)
            },
            onDismiss = { dialog = null },
        )

        is FileDialog.Delete -> ConfirmDialog(
            title = "Delete ${d.items.size} item${if (d.items.size == 1) "" else "s"}?",
            message = (if (d.items.size == 1) "“${d.items[0].name}”" else "The selected items") +
                " will move to the Recycle bin. You can restore them within 30 days.",
            confirmText = "Move to Recycle bin",
            onConfirm = {
                dialog = null
                vm.delete(d.items)
            },
            onDismiss = { dialog = null },
        )

        is FileDialog.Secure -> ConfirmDialog(
            title = "Move to Secure folder?",
            message = "${d.items.size} item${if (d.items.size == 1) "" else "s"} will be hidden and locked behind your PIN. Uninstalling the app deletes the Secure folder.",
            confirmText = "Move",
            onConfirm = {
                dialog = null
                vm.moveToSecure(d.items)
            },
            onDismiss = { dialog = null },
        )

        is FileDialog.Details -> DetailsDialog(d.item, onClose = { dialog = null })

        is FileDialog.Extract -> androidx.compose.material3.AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Extract ZIP?") },
            text = { Text("Extract “${d.item.name}” into a new folder next to it?") },
            confirmButton = {
                TextButton(onClick = {
                    dialog = null
                    vm.extract(d.item)
                }) { Text("Extract", fontWeight = FontWeight.SemiBold) }
            },
            dismissButton = {
                TextButton(onClick = {
                    dialog = null
                    openFile(ctx, d.item)
                }) { Text("Open with…") }
            },
        )

        null -> {}
    }
}

@Composable
private fun SearchTopBar(query: String, placeholder: String, onQuery: (String) -> Unit, onClose: () -> Unit) {
    val focus = remember { FocusRequester() }
    TopAppBar(
        title = {
            LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
            TextField(
                value = query,
                onValueChange = onQuery,
                placeholder = { Text(placeholder) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .focusRequester(focus),
            )
        },
        navigationIcon = {
            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Close search") }
        },
        actions = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQuery("") }) { Icon(Icons.Rounded.Close, "Clear") }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
    )
}

@Composable
private fun BrowseHeader(vm: FilesViewModel, dir: String, roots: List<StorageRoot>) {
    val root = vm.rootFor(dir)
    val crumbs = remember(dir, root) {
        val list = ArrayList<Pair<String, String>>()
        list.add(root.name to root.path)
        var current = root.path
        dir.removePrefix(root.path).split('/').filter { it.isNotEmpty() }.forEach { part ->
            current = "$current/$part"
            list.add(part to current)
        }
        list
    }
    val listState = rememberLazyListState()
    LaunchedEffect(crumbs.size, dir) { listState.scrollToItem(crumbs.lastIndex) }

    Column {
        if (roots.size > 1) {
            Row(
                Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                roots.forEach { r ->
                    FilterChip(
                        selected = r.path == root.path,
                        onClick = { vm.openFolder(r.path) },
                        label = { Text(r.name) },
                    )
                }
            }
        }
        LazyRow(
            state = listState,
            contentPadding = PaddingValues(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            itemsIndexed(crumbs) { index, crumb ->
                val isLast = index == crumbs.lastIndex
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (index > 0) {
                        Icon(
                            Icons.Rounded.ChevronRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                        )
                    }
                    Text(
                        crumb.first,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isLast) FontWeight.Bold else FontWeight.Normal,
                        color = if (isLast) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(enabled = !isLast) { vm.openFolder(crumb.second) }
                            .padding(horizontal = 6.dp, vertical = 10.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun ActiveFilterBar(label: String, onClear: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "Showing only: $label",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = onClear) { Text("Clear") }
    }
}

@Composable
private fun EmptyContent(ui: UiState, scanning: Boolean) {
    val restricted = ui.tab == NavTab.Browse &&
        (ui.dir.contains("/Android/data") || ui.dir.contains("/Android/obb"))
    when {
        ui.searching && ui.query.isBlank() && ui.tab == NavTab.Home ->
            EmptyState(Icons.Rounded.Search, "Search all files", "Type a name to find files anywhere on your phone.")

        ui.searching && ui.query.isNotBlank() ->
            EmptyState(Icons.Rounded.Search, "No results", "Nothing matches “${ui.query}”.")

        ui.largeFiles ->
            EmptyState(Icons.Rounded.Folder, "No large files", "Nothing bigger than the large-file limit was found.")

        ui.tab == NavTab.Recent ->
            EmptyState(Icons.Rounded.History, "No recent files", "Files you add or change will show up here.")

        ui.filter != null && ui.category == null ->
            EmptyState(Icons.Rounded.FilterList, "Nothing matches your filter", "Try a different filter.")

        ui.tab == NavTab.Favourites ->
            EmptyState(
                Icons.Rounded.FavoriteBorder,
                "No favourites yet",
                "Tap the heart on any file or folder to keep it here.",
            )

        ui.category != null && scanning ->
            EmptyState(Icons.Rounded.Search, "Scanning…", "Looking through your files.")

        ui.category != null ->
            EmptyState(Icons.Rounded.Folder, "No ${ui.category?.label ?: "files"} found", "Nothing of this type is on your phone yet.")

        restricted ->
            EmptyState(Icons.Rounded.Folder, "Restricted by Android", "Android doesn't let apps open this folder.")

        else ->
            EmptyState(Icons.Rounded.Folder, "This folder is empty", "Tap + to create a folder or text file.")
    }
}

@Composable
private fun PasteBar(clip: Clip, onPaste: () -> Unit, onCancel: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.primaryContainer) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Rounded.ContentPaste,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Text(
                "  ${clip.paths.size} item${if (clip.paths.size == 1) "" else "s"} to ${if (clip.cut) "move" else "copy"}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = onCancel) { Text("Cancel") }
            Button(onClick = onPaste) { Text("Paste here") }
        }
    }
}

@Composable
private fun SelectionBar(
    items: List<FileItem>,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    onRename: () -> Unit,
    onCompress: () -> Unit,
    onDetails: () -> Unit,
    onSecure: () -> Unit,
) {
    val has = items.isNotEmpty()
    var menu by remember { mutableStateOf(false) }
    val single = items.size == 1
    val canShare = has && items.any { !it.isDir }
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, shadowElevation = 8.dp) {
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            ActionButton(Icons.Rounded.ContentCopy, "Copy", has, onCopy)
            ActionButton(Icons.Rounded.ContentCut, "Move", has, onMove)
            ActionButton(Icons.Rounded.Delete, "Delete", has, onDelete)
            ActionButton(Icons.Rounded.Share, "Share", canShare, onShare)
            Box {
                ActionButton(Icons.Rounded.MoreVert, "More", has) { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Rename") },
                        leadingIcon = { Icon(Icons.Rounded.DriveFileRenameOutline, null) },
                        enabled = single,
                        onClick = {
                            menu = false
                            onRename()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Move to Secure folder") },
                        leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                        onClick = {
                            menu = false
                            onSecure()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Compress to ZIP") },
                        leadingIcon = { Icon(Icons.Rounded.Archive, null) },
                        onClick = {
                            menu = false
                            onCompress()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Details") },
                        leadingIcon = { Icon(Icons.Rounded.Info, null) },
                        enabled = single,
                        onClick = {
                            menu = false
                            onDetails()
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionButton(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    val tint = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
    Column(
        Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = label, tint = tint)
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint)
    }
}
