@file:OptIn(ExperimentalMaterial3Api::class)

package com.clearfiles.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.SdCard
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Usb
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.clearfiles.app.data.FileItem
import com.clearfiles.app.data.FileType
import com.clearfiles.app.data.StorageBreakdown
import com.clearfiles.app.data.StorageKind
import com.clearfiles.app.util.formatSize

private data class Tile(
    val label: String,
    val icon: ImageVector,
    val color: Color,
    val subtitle: String,
    val onClick: () -> Unit,
)

@Composable
fun HomeContent(
    breakdowns: List<StorageBreakdown>,
    counts: Map<FileType, Int>,
    recents: List<FileItem>,
    favCount: Int,
    scanning: Boolean,
    trashCount: Int,
    onSeeAllRecent: () -> Unit,
    onCategory: (FileType) -> Unit,
    onDownloads: () -> Unit,
    onFavourites: () -> Unit,
    onStorage: (StorageBreakdown) -> Unit,
    onMissingStorage: (String) -> Unit,
    onDuplicates: () -> Unit,
    onLargeFiles: () -> Unit,
    onTrash: () -> Unit,
    onSecure: () -> Unit,
    onOpen: (FileItem) -> Unit,
) {
    fun countText(type: FileType): String {
        val n = counts[type]
        return when {
            n != null -> "$n file${if (n == 1) "" else "s"}"
            scanning -> "…"
            else -> "0 files"
        }
    }

    fun categoryTile(type: FileType, label: String = type.label) = Tile(
        label = label,
        icon = typeIcon(type),
        color = typeColor(type),
        subtitle = countText(type),
        onClick = { onCategory(type) },
    )

    val categories = listOf(
        categoryTile(FileType.Image),
        categoryTile(FileType.Video),
        categoryTile(FileType.Audio),
        categoryTile(FileType.Document),
        categoryTile(FileType.Archive),
        categoryTile(FileType.Apk, "Install files"),
        Tile("Downloads", Icons.Rounded.Download, Color(0xFF0EA5A4), "Folder", onDownloads),
        Tile("Favourites", Icons.Rounded.Favorite, Color(0xFFFF4D79), "$favCount saved", onFavourites),
    )

    val analyze = listOf(
        Tile("Duplicate files", Icons.Rounded.ContentCopy, Color(0xFFEC4899), "Find copies", onDuplicates),
        Tile("Large files", Icons.Rounded.Storage, Color(0xFFF59E0B), "Biggest first", onLargeFiles),
        Tile("Recycle bin", Icons.Rounded.Delete, Color(0xFFEF4444), if (trashCount == 0) "Empty" else "$trashCount item${if (trashCount == 1) "" else "s"}", onTrash),
        Tile("Secure folder", Icons.Rounded.Lock, Color(0xFF10B981), "PIN protected", onSecure),
    )

    val internal = breakdowns.firstOrNull { it.root.kind == StorageKind.Internal }
    val sd = breakdowns.firstOrNull { it.root.kind == StorageKind.SdCard }
    val other = breakdowns.firstOrNull { it.root.kind == StorageKind.Other }

    LazyColumn(
        contentPadding = PaddingValues(top = 4.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionHeader("Recent files", "See all", onSeeAllRecent)
        }
        item {
            if (recents.isEmpty()) {
                Text(
                    if (scanning) "Scanning your files…" else "No files found yet",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
            } else {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(recents, key = { it.path }) { item ->
                        RecentCard(item) { onOpen(item) }
                    }
                }
            }
        }

        item { SectionHeader("Categories") }
        items(categories.chunked(3)) { rowTiles -> TileRow(rowTiles, 3) }

        item { SectionHeader("Storage") }
        item { StorageCard(StorageKind.Internal, internal, { internal?.let(onStorage) }) }
        item {
            StorageCard(StorageKind.SdCard, sd, {
                if (sd != null) onStorage(sd) else onMissingStorage("No SD card detected")
            })
        }
        item {
            StorageCard(StorageKind.Other, other, {
                if (other != null) onStorage(other) else onMissingStorage("No USB or other storage connected")
            })
        }

        item { SectionHeader("Analyze storage") }
        items(analyze.chunked(2)) { rowTiles -> TileRow(rowTiles, 2) }
    }
}

@Composable
private fun SectionHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp, top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        if (action != null) TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
private fun RecentCard(item: FileItem, onClick: () -> Unit) {
    Column(
        Modifier
            .width(96.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
    ) {
        FileThumb(item.path, item.type, 96.dp)
        Text(
            item.name,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp),
        )
    }
}

@Composable
private fun TileRow(rowTiles: List<Tile>, columns: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        rowTiles.forEach { tile -> TileCard(tile, Modifier.weight(1f)) }
        repeat(columns - rowTiles.size) { Spacer(Modifier.weight(1f)) }
    }
}

@Composable
private fun TileCard(tile: Tile, modifier: Modifier) {
    Surface(
        onClick = tile.onClick,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        shadowElevation = 1.dp,
    ) {
        Column(
            Modifier.padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(gradientBrush(tile.color)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(tile.icon, contentDescription = null, tint = Color.White)
            }
            Text(
                tile.label,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.padding(top = 8.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
            Text(
                tile.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                textAlign = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun StorageCard(kind: StorageKind, b: StorageBreakdown?, onClick: () -> Unit) {
    val icon = when (kind) {
        StorageKind.Internal -> Icons.Rounded.PhoneAndroid
        StorageKind.SdCard -> Icons.Rounded.SdCard
        StorageKind.Other -> Icons.Rounded.Usb
    }
    val gradient = when (kind) {
        StorageKind.Internal -> listOf(Color(0xFF2563EB), Color(0xFF7C4DFF))
        StorageKind.SdCard -> listOf(Color(0xFF10B981), Color(0xFF0EA5A4))
        StorageKind.Other -> listOf(Color(0xFFF59E0B), Color(0xFFEF4444))
    }
    val fallbackTitle = when (kind) {
        StorageKind.Internal -> "Internal storage"
        StorageKind.SdCard -> "SD card"
        StorageKind.Other -> "Other storage"
    }

    if (b == null) {
        Surface(
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            shadowElevation = 1.dp,
        ) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(44.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.outline)
                }
                Column(Modifier.padding(start = 14.dp)) {
                    Text(fallbackTitle, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Not available",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        return
    }

    Surface(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(22.dp),
        color = Color.Transparent,
    ) {
        Box(
            Modifier
                .background(Brush.linearGradient(gradient))
                .padding(18.dp),
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                    Text(
                        "  ${b.root.name}",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        formatSize(b.used),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.headlineSmall,
                    )
                    Text(
                        "  / ${formatSize(b.total)}",
                        color = Color(0xCCFFFFFF),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(bottom = 3.dp),
                    )
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { b.fraction },
                    color = Color.White,
                    trackColor = Color(0x44FFFFFF),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape),
                )
                Text(
                    "${formatSize(b.free)} free",
                    color = Color(0xCCFFFFFF),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }
}
