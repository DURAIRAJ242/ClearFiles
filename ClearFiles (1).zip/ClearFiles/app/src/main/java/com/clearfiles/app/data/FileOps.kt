package com.clearfiles.app.data

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Plain file-system helpers (no Android classes, so they are easy to test). */
object FileOps {

    const val MAX_EDIT_BYTES = 2L * 1024 * 1024

    /** Name of the Recycle bin folder created at the top of each storage. */
    const val TRASH_DIR = ".ClearFilesTrash"

    private const val QUICK_BYTES = 64L * 1024

    fun listDir(dir: File, showHidden: Boolean): List<FileItem> {
        val children = dir.listFiles() ?: return emptyList()
        return children
            .filter { it.name != TRASH_DIR && (showHidden || !it.name.startsWith(".")) }
            .map { it.toFileItem() }
    }

    private fun hashFile(file: File, limit: Long): String? = try {
        val md = MessageDigest.getInstance("MD5")
        val buf = ByteArray(64 * 1024)
        var remaining = limit
        FileInputStream(file).use { input ->
            while (remaining > 0) {
                val n = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                if (n <= 0) break
                md.update(buf, 0, n)
                remaining -= n
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        null
    }

    /**
     * Finds files with identical content: first by size, then by a hash of the first 64 KB,
     * then (only if still equal) by a hash of the whole file.
     */
    fun findDuplicates(files: List<FileItem>, isActive: () -> Boolean): List<DuplicateGroup> {
        val sameSize = files
            .filter { !it.isDir && it.size > 0 }
            .groupBy { it.size }
            .filter { it.value.size > 1 }
        val out = ArrayList<DuplicateGroup>()
        for ((size, group) in sameSize) {
            if (!isActive()) return out
            val quick = group.groupBy { hashFile(File(it.path), QUICK_BYTES) }
            for ((quickHash, candidates) in quick) {
                if (quickHash == null || candidates.size < 2) continue
                val sets: List<List<FileItem>> = if (size <= QUICK_BYTES) {
                    listOf(candidates)
                } else {
                    candidates.groupBy { hashFile(File(it.path), Long.MAX_VALUE) }
                        .filterKeys { it != null }
                        .values
                        .toList()
                }
                for (set in sets) {
                    if (set.size > 1) out.add(DuplicateGroup(size, set.sortedBy { it.modified }))
                }
            }
        }
        return out.sortedByDescending { it.wasted }
    }

    /** Walks every given storage root and returns all files (hidden folders and Android/ are skipped). */
    fun scanAll(roots: List<File>, isActive: () -> Boolean): List<FileItem> {
        val out = ArrayList<FileItem>(16384)
        for (root in roots) {
            val stack = ArrayList<File>()
            stack.add(root)
            while (stack.isNotEmpty()) {
                if (!isActive()) return out
                val dir = stack.removeAt(stack.lastIndex)
                val children = dir.listFiles() ?: continue
                for (f in children) {
                    val name = f.name
                    if (name.startsWith(".")) continue
                    if (f.isDirectory) {
                        if (dir == root && name == "Android") continue
                        stack.add(f)
                        out.add(f.toFileItem()) // folders are included so search can find them
                    } else {
                        out.add(f.toFileItem())
                    }
                }
            }
        }
        return out
    }

    /** "photo.jpg" -> "photo (1).jpg" when the name is already taken. */
    fun uniqueFile(dir: File, name: String): File {
        var target = File(dir, name)
        if (!target.exists()) return target
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (target.exists()) {
            target = File(dir, "$base ($i)$ext")
            i++
        }
        return target
    }

    fun copy(src: File, dst: File) {
        if (src.isDirectory) {
            if (!src.copyRecursively(dst, overwrite = false)) {
                throw IOException("Couldn't copy ${src.name}")
            }
        } else {
            src.copyTo(dst, overwrite = false)
        }
    }

    fun move(src: File, dst: File) {
        if (src.renameTo(dst)) return
        copy(src, dst)
        if (!src.deleteRecursively()) throw IOException("Copied, but couldn't remove the original")
    }

    /** Returns an error message, or null when [raw] is a usable file name. */
    fun validateName(raw: String): String? {
        val n = raw.trim()
        return when {
            n.isEmpty() -> "Name can't be empty"
            n == "." || n == ".." -> "Invalid name"
            n.contains('/') || n.contains('\u0000') -> "Name can't contain /"
            n.length > 200 -> "Name is too long"
            else -> null
        }
    }

    fun zip(sources: List<File>, target: File) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(target))).use { zos ->
            for (src in sources) {
                val parentLen = (src.parentFile?.path?.length ?: 0) + 1
                src.walkTopDown().forEach { f ->
                    if (f.path == target.path) return@forEach
                    var entryName = f.path.substring(parentLen).replace(File.separatorChar, '/')
                    if (f.isDirectory) entryName += "/"
                    zos.putNextEntry(ZipEntry(entryName))
                    if (f.isFile) {
                        FileInputStream(f).use { it.copyTo(zos) }
                    }
                    zos.closeEntry()
                }
            }
        }
    }

    fun unzip(zip: File, destDir: File) {
        destDir.mkdirs()
        val destCanonical = destDir.canonicalPath
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val out = File(destDir, entry.name)
                val outCanonical = out.canonicalPath
                // Block "zip slip": entries that try to escape the destination folder.
                if (outCanonical != destCanonical && !outCanonical.startsWith(destCanonical + File.separator)) {
                    throw IOException("This ZIP contains an unsafe path")
                }
                if (entry.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    /** Total size in bytes and number of files inside [dir]. */
    fun folderStats(dir: File): Pair<Long, Int> {
        var bytes = 0L
        var count = 0
        dir.walkTopDown().forEach { f ->
            if (f.isFile) {
                bytes += f.length()
                count++
            }
        }
        return bytes to count
    }

    fun readText(file: File, maxBytes: Long = MAX_EDIT_BYTES): String {
        if (file.length() > maxBytes) {
            throw IOException("File is too large to edit (limit ${maxBytes / 1024 / 1024} MB)")
        }
        return file.readText()
    }
}
