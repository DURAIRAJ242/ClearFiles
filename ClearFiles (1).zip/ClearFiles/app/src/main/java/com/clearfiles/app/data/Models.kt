package com.clearfiles.app.data

import java.io.File

enum class FileType(val label: String) {
    Folder("Folders"),
    Image("Images"),
    Video("Videos"),
    Audio("Audio"),
    Document("Documents"),
    Archive("Archives"),
    Apk("APKs"),
    Other("Other"),
}

private val IMAGE_EXT = setOf(
    "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif", "svg", "dng", "raw",
)
private val VIDEO_EXT = setOf(
    "mp4", "mkv", "webm", "3gp", "avi", "mov", "m4v", "flv", "wmv", "mpeg", "mpg",
)
private val AUDIO_EXT = setOf(
    "mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "amr", "wma", "mid", "midi",
)
private val ARCHIVE_EXT = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz")
private val APK_EXT = setOf("apk", "apks", "xapk")

/** Plain-text style files that the built-in editor can open and save. */
val EDITABLE_EXT = setOf(
    "txt", "md", "log", "json", "xml", "html", "htm", "css", "js", "ts", "kt", "kts", "java",
    "py", "c", "h", "cpp", "sh", "ini", "conf", "cfg", "yml", "yaml", "properties", "csv",
    "srt", "gradle", "sql", "bat", "tex", "vcf", "ics",
)

private val DOCUMENT_EXT = EDITABLE_EXT + setOf(
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "rtf", "epub",
)

fun typeForExtension(ext: String): FileType = when (ext) {
    in IMAGE_EXT -> FileType.Image
    in VIDEO_EXT -> FileType.Video
    in AUDIO_EXT -> FileType.Audio
    in ARCHIVE_EXT -> FileType.Archive
    in APK_EXT -> FileType.Apk
    in DOCUMENT_EXT -> FileType.Document
    else -> FileType.Other
}

/** One file or folder shown in a list. */
data class FileItem(
    val path: String,
    val name: String,
    val isDir: Boolean,
    val size: Long,
    val modified: Long,
    val ext: String,
    val type: FileType,
    val childCount: Int,
)

val FileItem.isEditable: Boolean get() = !isDir && ext in EDITABLE_EXT

fun File.toFileItem(): FileItem {
    val dir = isDirectory
    val extension = if (dir) "" else this.extension.lowercase()
    return FileItem(
        path = path,
        name = name,
        isDir = dir,
        size = if (dir) 0L else length(),
        modified = lastModified(),
        ext = extension,
        type = if (dir) FileType.Folder else typeForExtension(extension),
        childCount = if (dir) (list()?.size ?: 0) else 0,
    )
}

enum class SortField(val label: String) {
    Name("Name"),
    Date("Date modified"),
    Size("Size"),
    Type("Type"),
}

enum class NavTab { Home, Recent, Browse, Favourites }

enum class StorageKind { Internal, SdCard, Other }

data class StorageRoot(
    val name: String,
    val path: String,
    val primary: Boolean,
    val kind: StorageKind = if (primary) StorageKind.Internal else StorageKind.SdCard,
)

/** Full-screen tools that open on top of the main screen. */
enum class Screen { Duplicates, RecycleBin, Secure, StorageDetail }

/** How one storage (internal, SD card...) is used, split by file type. */
data class StorageBreakdown(
    val root: StorageRoot,
    val total: Long,
    val free: Long,
    val byType: Map<FileType, Long>,
) {
    val used: Long get() = (total - free).coerceAtLeast(0L)
    val filesBytes: Long get() = byType.values.sum()
    /** Space used by Android, apps and anything the file scan can't see. */
    val systemBytes: Long get() = (used - filesBytes).coerceAtLeast(0L)
    val fraction: Float get() = if (total > 0) (used.toFloat() / total).coerceIn(0f, 1f) else 0f
}

/** Identical files (same size and same content). The oldest copy comes first. */
data class DuplicateGroup(val size: Long, val items: List<FileItem>) {
    val wasted: Long get() = size * (items.size - 1)
}

data class StorageInfo(val total: Long, val free: Long) {
    val used: Long get() = (total - free).coerceAtLeast(0L)
    val fraction: Float get() = if (total > 0) (used.toFloat() / total).coerceIn(0f, 1f) else 0f
}

/** Files waiting to be pasted. [cut] = move, otherwise copy. */
data class Clip(val paths: List<String>, val cut: Boolean)

data class EditorState(val path: String, val name: String, val text: String)

data class UiState(
    val tab: NavTab = NavTab.Home,
    val dir: String,
    /** Set when a category (Images, Videos...) is open from the Home tab. */
    val category: FileType? = null,
    /** Home tab: show the biggest files on the phone. */
    val largeFiles: Boolean = false,
    val sortField: SortField = SortField.Name,
    val ascending: Boolean = true,
    /** null = show everything. */
    val filter: FileType? = null,
    val showHidden: Boolean = false,
    val query: String = "",
    val searching: Boolean = false,
)

/** Folders always come first; then the chosen field in the chosen direction. */
fun sortItems(items: List<FileItem>, field: SortField, ascending: Boolean): List<FileItem> {
    val byField: Comparator<FileItem> = when (field) {
        SortField.Name -> Comparator { a, b -> a.name.compareTo(b.name, ignoreCase = true) }
        SortField.Date -> Comparator { a, b -> a.modified.compareTo(b.modified) }
        SortField.Size -> Comparator { a, b -> a.size.compareTo(b.size) }
        SortField.Type -> Comparator { a, b ->
            val c = a.ext.compareTo(b.ext, ignoreCase = true)
            if (c != 0) c else a.name.compareTo(b.name, ignoreCase = true)
        }
    }
    val directed: Comparator<FileItem> = if (ascending) byField else byField.reversed()
    return items.sortedWith(
        Comparator { a, b ->
            if (a.isDir != b.isDir) {
                if (a.isDir) -1 else 1
            } else {
                directed.compare(a, b)
            }
        },
    )
}
