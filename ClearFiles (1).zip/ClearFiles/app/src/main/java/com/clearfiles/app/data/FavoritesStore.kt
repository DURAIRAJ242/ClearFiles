package com.clearfiles.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Favourites are remembered privately inside the app (by path) — your files are never touched. */
class FavoritesStore(context: Context) {
    private val prefs = context.getSharedPreferences("favorites", Context.MODE_PRIVATE)
    private val _paths = MutableStateFlow<Set<String>>(
        prefs.getStringSet("paths", emptySet())?.toSet() ?: emptySet(),
    )
    val paths: StateFlow<Set<String>> = _paths

    private fun commit(next: Set<String>) {
        _paths.value = next
        prefs.edit().putStringSet("paths", HashSet(next)).apply()
    }

    fun toggle(path: String) {
        val current = _paths.value
        commit(if (path in current) current - path else current + path)
    }

    fun setAll(paths: Collection<String>, favorite: Boolean) {
        val current = _paths.value
        commit(if (favorite) current + paths else current - paths.toSet())
    }

    fun remove(path: String) {
        val current = _paths.value
        if (path in current) commit(current - path)
    }

    fun replace(old: String, new: String) {
        val current = _paths.value
        if (old in current) commit(current - old + new)
    }
}
