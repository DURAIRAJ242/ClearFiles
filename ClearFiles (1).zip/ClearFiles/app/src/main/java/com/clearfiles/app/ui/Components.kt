@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.clearfiles.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.clearfiles.app.data.FileItem
import com.clearfiles.app.data.FileType
import com.clearfiles.app.ui.theme.FavoriteRed
import com.clearfiles.app.util.formatSize
import com.clearfiles.app.util.shortDate
import java.io.File

fun typeColor(type: FileType): Color = when (type) {
    FileType.Folder -> Color(0xFFF5A623)
    FileType.Image -> Color(0xFF22B573)
    FileType.Video -> Color(0xFF8B5CF6)
    FileType.Audio -> Color(0xFFEC4899)
    FileType.Document -> Color(0xFF3B82F6)
    FileType.Archive -> Color(0xFFF97316)
    FileType.Apk -> Color(0xFF14B8A6)
    FileType.Other -> Color(0xFF7B8499)
}

fun typeIcon(type: FileType): ImageVector = when (type) {
    FileType.Folder -> Icons.Rounded.Folder
    FileType.Image -> Icons.Rounded.Image
    FileType.Video -> Icons.Rounded.Movie
    FileType.Audio -> Icons.Rounded.MusicNote
    FileType.Document -> Icons.Rounded.Description
    FileType.Archive -> Icons.Rounded.Archive
    FileType.Apk -> Icons.Rounded.Android
    FileType.Other -> Icons.Rounded.InsertDriveFile
}

/** Colourful gradient used behind icons (Samsung-style tiles). */
fun gradientBrush(color: Color): Brush =
    Brush.linearGradient(listOf(color, lerp(color, Color(0xFF7C4DFF), 0.4f)))

/** Rounded square with the file-type icon; photos and videos show a real thumbnail. */
@Composable
fun FileThumb(path: String, type: FileType, size: Dp, modifier: Modifier = Modifier) {
    val color = typeColor(type)
    Box(
        modifier
            .size(size)
            .clip(RoundedCornerShape(14.dp))
            .background(color.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(typeIcon(type), contentDescription = null, tint = color)
        if (type == FileType.Image || type == FileType.Video) {
            val ctx = LocalContext.current
            val request = remember(path) {
                ImageRequest.Builder(ctx)
                    .data(File(path))
                    .size(256)
                    .setParameter("coil#video_frame_micros", 1_000_000L)
                    .crossfade(true)
                    .build()
            }
            AsyncImage(
                model = request,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

/** Swallows touches so nothing underneath an overlay can be tapped. */
@Composable
fun Modifier.blockTouches(): Modifier = this.clickable(
    interactionSource = remember { MutableInteractionSource() },
    indication = null,
    onClick = {},
)

@Composable
fun FileRow(
    item: FileItem,
    favorite: Boolean,
    selected: Boolean,
    selecting: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onToggleFav: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val color = typeColor(item.type)
    val subtitle = if (item.isDir) {
        "${item.childCount} item${if (item.childCount == 1) "" else "s"} · ${shortDate(item.modified)}"
    } else {
        "${formatSize(item.size)} · ${shortDate(item.modified)}"
    }
    Row(
        modifier
            .fillMaxWidth()
            .background(
                if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else Color.Transparent,
            )
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FileThumb(item.path, item.type, 46.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.name,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (selecting) {
            Icon(
                if (selected) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                modifier = Modifier.padding(12.dp),
            )
        } else {
            IconButton(onClick = onToggleFav) {
                Icon(
                    if (favorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    contentDescription = if (favorite) "Remove from favourites" else "Add to favourites",
                    tint = if (favorite) FavoriteRed else MaterialTheme.colorScheme.outline,
                )
            }
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, message: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier
                .size(88.dp)
                .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(40.dp),
            )
        }
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 20.dp),
            textAlign = TextAlign.Center,
        )
        Text(
            message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp),
            textAlign = TextAlign.Center,
        )
    }
}
